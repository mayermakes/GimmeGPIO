#include <ESP32CommandInterface.h>

ESP32CommandInterface cmd;

void setup() {
  cmd.begin();
}

void loop() {
  cmd.handle();
}
