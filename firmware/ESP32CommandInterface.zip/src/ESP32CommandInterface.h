#ifndef ESP32COMMANDINTERFACE_H
#define ESP32COMMANDINTERFACE_H

#include <Arduino.h>
#include <Wire.h>

class ESP32CommandInterface {
  public:
    ESP32CommandInterface(int uart_rx = 18, int uart_tx = 17, int i2c_sda = 8, int i2c_scl = 9);
    void begin(uint32_t baud = 115200);
    void handle();
    void parseCommand(String cmd);

  private:
    int _uart_rx, _uart_tx;
    int _i2c_sda, _i2c_scl;
    bool uartPassthrough;
    HardwareSerial* hwSerial;
};

#endif
