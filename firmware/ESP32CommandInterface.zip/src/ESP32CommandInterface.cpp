#include "ESP32CommandInterface.h"

ESP32CommandInterface::ESP32CommandInterface(int uart_rx, int uart_tx, int i2c_sda, int i2c_scl) {
  _uart_rx = uart_rx;
  _uart_tx = uart_tx;
  _i2c_sda = i2c_sda;
  _i2c_scl = i2c_scl;
  uartPassthrough = false;
  hwSerial = new HardwareSerial(1);
}

void ESP32CommandInterface::begin(uint32_t baud) {
  Serial.begin(baud);  // USB CDC
  hwSerial->begin(baud, SERIAL_8N1, _uart_rx, _uart_tx);
  Wire.begin(_i2c_sda, _i2c_scl);
  Serial.println("ESP32-S2 Command Interface Ready");
}

void ESP32CommandInterface::handle() {
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    parseCommand(cmd);
  }

  if (uartPassthrough) {
    while (Serial.available()) hwSerial->write(Serial.read());
    while (hwSerial->available()) Serial.write(hwSerial->read());
  }
}

void ESP32CommandInterface::parseCommand(String cmd) {
  if (cmd.startsWith("setpin")) {
    int pin = cmd.substring(cmd.indexOf('(') + 1, cmd.indexOf(',')).toInt();
    int state = cmd.substring(cmd.indexOf(',') + 1, cmd.indexOf(')')).toInt();
    pinMode(pin, OUTPUT);
    digitalWrite(pin, state ? HIGH : LOW);
    Serial.printf("Pin %d set to %d\n", pin, state);

  } else if (cmd.startsWith("setpwm")) {
    int pin = cmd.substring(cmd.indexOf('(') + 1, cmd.indexOf(',')).toInt();
    int pwm = cmd.substring(cmd.indexOf(',') + 1, cmd.indexOf(')')).toInt();
    ledcAttachPin(pin, pin); 
    ledcSetup(pin, 5000, 8); 
    ledcWrite(pin, pwm);
    Serial.printf("PWM set on pin %d: %d\n", pin, pwm);

  } else if (cmd.startsWith("readpin")) {
    int pin = cmd.substring(cmd.indexOf('(') + 1, cmd.indexOf(')')).toInt();
    pinMode(pin, INPUT);
    Serial.printf("Pin %d reads %d\n", pin, digitalRead(pin));

  } else if (cmd.startsWith("analogread")) {
    int pin = cmd.substring(cmd.indexOf('(') + 1, cmd.indexOf(')')).toInt();
    Serial.printf("Analog read pin %d: %d\n", pin, analogRead(pin));

  } else if (cmd.startsWith("UART")) {
    int state = cmd.substring(cmd.indexOf('(') + 1, cmd.indexOf(')')).toInt();
    uartPassthrough = (state == 1);
    Serial.printf("UART passthrough %s\n", uartPassthrough ? "enabled" : "disabled");

  } else if (cmd.startsWith("I2C(write")) {
    int p1 = cmd.indexOf('(');
    int p2 = cmd.indexOf(',');
    int p3 = cmd.indexOf(',', p2 + 1);
    int p4 = cmd.indexOf(')');
    int addr = cmd.substring(p1 + 1, p2).toInt();
    int data = cmd.substring(p3 + 1, p4).toInt();
    Wire.beginTransmission(addr);
    Wire.write((uint8_t)data);
    Wire.endTransmission();
    Serial.printf("I2C write to 0x%02X: 0x%02X\n", addr, data);

  } else if (cmd.startsWith("I2C(read")) {
    int p1 = cmd.indexOf('(');
    int p2 = cmd.indexOf(',');
    int p3 = cmd.indexOf(')');
    int addr = cmd.substring(p1 + 1, p2).toInt();
    int len = cmd.substring(p2 + 1, p3).toInt();
    Wire.requestFrom(addr, len);
    Serial.printf("I2C read from 0x%02X: ", addr);
    while (Wire.available()) Serial.printf("0x%02X ", Wire.read());
    Serial.println();

  } else {
    Serial.println("Unknown command");
  }
}
